pip install pandas matplotlib statsmodels
import pandas as pd, matplotlib.pyplot as plt, statsmodels.api as sm
from statsmodels.stats.outliers_influence import variance_inflation_factor
df = pd.read_csv("Housing.csv")[["price","area","bedrooms","bathrooms"]]
X = sm.add_constant(df.drop("price", axis=1))
m = sm.OLS(df["price"], X).fit()
print(m.summary())
for i in range(1,4): print(X.columns[i], "VIF:", round(variance_inflation_factor(X.values, i), 2))
plt.scatter(m.fittedvalues, m.resid); plt.title("Residuals"); plt.show()
plt.stem(m.get_influence().cooks_distance[0]); plt.title("Cook's Distance"); plt.show()
