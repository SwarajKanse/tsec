pip install pandas
import pandas as pd
df = pd.read_csv("Titanic-Dataset.csv")
srs = df.sample(50)
strat = df.groupby("Pclass").sample(20)
clust = df[df["Pclass"] == 1]
print("Pop:", df["Age"].mean(), "SRS:", srs["Age"].mean())
print("Strat:", strat["Age"].mean(), "Cluster:", clust["Age"].mean())
print("Strat Counts:", strat["Pclass"].value_counts().to_dict())
