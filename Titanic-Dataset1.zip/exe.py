pip install pandas seaborn matplotlib
import pandas as pd, seaborn as sns, matplotlib.pyplot as plt
df = pd.read_csv("Iris.csv").drop("Id", axis=1)
print(df.describe())
df.hist(); plt.show()
sns.heatmap(df.corr(numeric_only=True), annot=True); plt.show()
