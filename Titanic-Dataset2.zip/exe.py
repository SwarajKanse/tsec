pip install pandas matplotlib scikit-learn
import pandas as pd, matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
df = pd.read_csv("Titanic-Dataset.csv")[["Age","Fare","Sex","Embarked"]]
print("Missing:\n", df.isnull().sum())
df = df.fillna(df.mean(numeric_only=True)).dropna()
df.boxplot(); plt.show()
df = df[abs(df["Fare"] - df["Fare"].mean()) < 3 * df["Fare"].std()]
df = pd.get_dummies(df, dtype=int)
df[["Age","Fare"]] = StandardScaler().fit_transform(df[["Age","Fare"]])
print(df.head())
