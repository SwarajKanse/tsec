pip install pandas matplotlib scikit-learn
import pandas as pd, matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import confusion_matrix, RocCurveDisplay
df = pd.read_csv("Titanic-Dataset.csv")[["Survived","Pclass","Age","Fare"]].dropna()
Xtr, Xte, ytr, yte = train_test_split(df.drop("Survived",axis=1), df["Survived"])
for m in [LogisticRegression(max_iter=200), KNeighborsClassifier(), GaussianNB()]:
    m.fit(Xtr, ytr)
    print(type(m).__name__, "Acc:", m.score(Xte, yte))
    print(confusion_matrix(yte, m.predict(Xte)))
    RocCurveDisplay.from_estimator(m, Xte, yte, ax=plt.gca())
plt.show()
