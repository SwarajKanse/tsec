pip install pandas scipy statsmodels
import pandas as pd
from scipy.stats import ttest_ind, f_oneway, chi2_contingency
from statsmodels.stats.weightstats import ztest
df = pd.read_csv("Titanic-Dataset.csv")
g1 = df[df["Pclass"]==1]["Fare"]
g2 = df[df["Pclass"]==2]["Fare"]
g3 = df[df["Pclass"]==3]["Fare"]
print("z-test  p =", round(ztest(g1, g2)[1], 4))
print("t-test  p =", round(ttest_ind(g1, g2)[1], 4))
print("ANOVA   p =", round(f_oneway(g1, g2, g3)[1], 4))
print("Chi2    p =", round(chi2_contingency(pd.crosstab(df["Sex"], df["Survived"]))[1], 4))
