pip install pandas matplotlib scikit-learn
import pandas as pd, matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.ensemble import RandomForestClassifier
df = pd.read_csv("Iris.csv").drop("Id", axis=1)
X, y = df.drop("Species", axis=1), df["Species"]
Xtr, Xte, ytr, yte = train_test_split(X, y)
dt = DecisionTreeClassifier(max_depth=3).fit(Xtr, ytr)
rf = RandomForestClassifier().fit(Xtr, ytr)
print("DT:", dt.score(Xte, yte), "RF:", rf.score(Xte, yte))
plt.barh(X.columns, rf.feature_importances_); plt.title("Feature Importance"); plt.show()
plot_tree(dt, filled=True, feature_names=X.columns); plt.show()
